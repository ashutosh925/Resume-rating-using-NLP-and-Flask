import React, { Component } from 'react';

class ResourceNotFoundComponent extends Component {
    render() {
        return <h1>Not found</h1>;
    }
}

export default ResourceNotFoundComponent;